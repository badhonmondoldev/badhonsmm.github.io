import React, { useState, useEffect } from 'react';
import { 
  Routes, 
  Route, 
  Link, 
  useNavigate, 
  useLocation, 
  Navigate,
  useSearchParams
} from 'react-router-dom';
import { 
  LayoutDashboard, 
  ShoppingCart, 
  List, 
  History, 
  User, 
  LogOut, 
  Plus, 
  TrendingUp, 
  Clock, 
  CheckCircle2, 
  AlertCircle,
  Menu,
  X,
  CreditCard,
  ShieldCheck,
  Users,
  Settings,
  Trash2,
  Edit,
  Search,
  Filter
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- Types ---
interface User {
  id: number;
  username: string;
  email: string;
  balance: number;
  is_admin?: number;
}

interface Service {
  id: number;
  name: string;
  category: string;
  rate: number;
  min: number;
  max: number;
  description: string;
}

interface Order {
  id: number;
  service_name: string;
  link: string;
  quantity: number;
  status: string;
  charge: number;
  created_at: string;
}

// --- Components ---

const Sidebar = ({ user, onLogout, isOpen, onClose }: { 
  user: User,
  onLogout: () => void,
  isOpen: boolean,
  onClose: () => void
}) => {
  const location = useLocation();
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, path: '/' },
    { id: 'new-order', label: 'New Order', icon: ShoppingCart, path: '/new-order' },
    { id: 'add-funds', label: 'Add Funds', icon: CreditCard, path: '/add-funds' },
    { id: 'services', label: 'Services', icon: List, path: '/services' },
    { id: 'orders', label: 'Order History', icon: History, path: '/orders' },
    { id: 'profile', label: 'My Profile', icon: User, path: '/profile' },
  ];

  if (user.is_admin) {
    menuItems.push({ id: 'admin', label: 'Admin Panel', icon: ShieldCheck, path: '/admin' });
  }

  return (
    <>
      {/* Mobile Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
          />
        )}
      </AnimatePresence>

      <div className={`w-64 bg-zinc-950 border-r border-zinc-800 h-screen flex flex-col fixed left-0 top-0 z-50 transition-transform duration-300 lg:translate-x-0 ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="p-6 border-b border-zinc-800 flex items-center justify-between">
          <Link to="/" onClick={onClose} className="text-xl font-bold text-white flex items-center gap-2">
            <TrendingUp className="text-emerald-500" />
            badhon smm
          </Link>
          <button onClick={onClose} className="lg:hidden text-zinc-400 hover:text-white">
            <X size={24} />
          </button>
        </div>
        
        <div className="flex-1 py-6 px-4 space-y-2 overflow-y-auto">
          {menuItems.map((item) => (
            <Link
              key={item.id}
              to={item.path}
              onClick={onClose}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                location.pathname === item.path 
                  ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20' 
                  : 'text-zinc-400 hover:bg-zinc-900 hover:text-white'
              }`}
            >
              <item.icon size={20} />
              <span className="font-medium">{item.label}</span>
            </Link>
          ))}
        </div>

        <div className="p-4 border-t border-zinc-800 space-y-4">
          <div className="bg-zinc-900 rounded-xl p-4 border border-zinc-800">
            <p className="text-xs text-zinc-500 uppercase tracking-wider font-semibold mb-1">Balance</p>
            <p className="text-xl font-bold text-white">${user.balance.toFixed(2)}</p>
          </div>
          <button 
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-zinc-400 hover:bg-red-500/10 hover:text-red-500 transition-all"
          >
            <LogOut size={20} />
            <span className="font-medium">Logout</span>
          </button>
        </div>
      </div>
    </>
  );
};

const Dashboard = ({ user, orders }: { user: User, orders: Order[] }) => {
  const stats = [
    { label: 'Total Orders', value: orders.length, icon: ShoppingCart, color: 'text-blue-500', bg: 'bg-blue-500/10' },
    { label: 'Completed', value: orders.filter(o => o.status === 'completed').length, icon: CheckCircle2, color: 'text-emerald-500', bg: 'bg-emerald-500/10' },
    { label: 'Pending', value: orders.filter(o => o.status === 'pending').length, icon: Clock, color: 'text-amber-500', bg: 'bg-amber-500/10' },
    { label: 'Total Spent', value: `$${orders.reduce((acc, o) => acc + o.charge, 0).toFixed(2)}`, icon: CreditCard, color: 'text-purple-500', bg: 'bg-purple-500/10' },
  ];

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
        {stats.map((stat, i) => (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            key={stat.label}
            className="bg-zinc-900/50 backdrop-blur-md border border-zinc-800 p-6 rounded-[2rem] hover:border-zinc-700 transition-all group"
          >
            <div className="flex items-center justify-between mb-4">
              <div className={`p-3 rounded-2xl ${stat.bg} border border-white/5 ${stat.color} group-hover:scale-110 transition-transform`}>
                <stat.icon size={24} />
              </div>
            </div>
            <p className="text-zinc-500 text-xs font-black uppercase tracking-widest">{stat.label}</p>
            <p className="text-3xl font-black text-white mt-1">{stat.value}</p>
          </motion.div>
        ))}
      </div>

      <div className="bg-zinc-900/50 backdrop-blur-md border border-zinc-800 rounded-[2rem] overflow-hidden">
        <div className="p-6 border-b border-zinc-800 flex items-center justify-between">
          <h2 className="text-lg font-black text-white uppercase tracking-tight">Recent Orders</h2>
          <Link to="/orders" className="text-emerald-500 text-xs font-black uppercase tracking-widest hover:underline">View All</Link>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-zinc-950/50 text-zinc-500 text-[10px] font-black uppercase tracking-widest">
              <tr>
                <th className="px-6 py-4">ID</th>
                <th className="px-6 py-4">Service</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Charge</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/50">
              {orders.slice(0, 5).map((order) => (
                <tr key={order.id} className="hover:bg-zinc-800/30 transition-colors">
                  <td className="px-6 py-4 text-zinc-500 font-mono text-xs">#{order.id}</td>
                  <td className="px-6 py-4 text-white font-bold text-sm">{order.service_name}</td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-tighter ${
                      order.status === 'completed' ? 'bg-emerald-500/10 text-emerald-500' :
                      order.status === 'pending' ? 'bg-amber-500/10 text-amber-500' :
                      'bg-zinc-800 text-zinc-400'
                    }`}>
                      {order.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-white font-black text-sm">${order.charge.toFixed(2)}</td>
                </tr>
              ))}
              {orders.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-6 py-12 text-center text-zinc-500 font-medium">No orders found yet.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const NewOrder = ({ services, user, onOrderPlaced }: { services: Service[], user: User, onOrderPlaced: () => void }) => {
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedServiceId, setSelectedServiceId] = useState('');
  const [serviceSearch, setServiceSearch] = useState('');
  const [link, setLink] = useState('');
  const [quantity, setQuantity] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const categories = Array.from(new Set(services.map(s => s.category)));
  const filteredServices = services.filter(s => {
    const matchesCategory = s.category === selectedCategory;
    const matchesSearch = s.name.toLowerCase().includes(serviceSearch.toLowerCase()) || 
                         s.id.toString().includes(serviceSearch);
    return matchesCategory && matchesSearch;
  });
  const selectedService = services.find(s => s.id === parseInt(selectedServiceId));

  const totalCharge = selectedService ? (selectedService.rate * parseInt(quantity || '0')) / 1000 : 0;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedServiceId || !link || !quantity) return;
    
    setLoading(true);
    setError('');
    
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          serviceId: parseInt(selectedServiceId),
          link,
          quantity: parseInt(quantity)
        })
      });
      
      const data = await res.json();
      if (data.success) {
        onOrderPlaced();
        setLink('');
        setQuantity('');
        alert('Order placed successfully!');
      } else {
        setError(data.error);
      }
    } catch (err) {
      setError('Failed to place order');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-zinc-900/50 backdrop-blur-md border border-zinc-800 rounded-[2.5rem] p-6 lg:p-10 shadow-2xl"
      >
        <h2 className="text-2xl font-black text-white mb-8 flex items-center gap-3 uppercase tracking-tight">
          <div className="p-2 bg-emerald-500/10 rounded-xl border border-emerald-500/20">
            <Plus className="text-emerald-500" size={24} />
          </div>
          New Order
        </h2>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="block text-xs font-black text-zinc-500 uppercase tracking-widest ml-1">Category</label>
            <select
              value={selectedCategory}
              onChange={(e) => {
                setSelectedCategory(e.target.value);
                setSelectedServiceId('');
              }}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl px-5 py-4 text-white focus:ring-2 focus:ring-emerald-500 outline-none transition-all appearance-none cursor-pointer"
              required
            >
              <option value="">Select Category</option>
              {categories.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          <div className="space-y-2">
            <label className="block text-xs font-black text-zinc-500 uppercase tracking-widest ml-1">Service</label>
            {selectedCategory && (
              <input
                type="text"
                placeholder="Search service in this category..."
                value={serviceSearch}
                onChange={(e) => setServiceSearch(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl px-5 py-3 text-white focus:ring-2 focus:ring-emerald-500 outline-none transition-all placeholder:text-zinc-800 mb-2 text-sm"
              />
            )}
            <select
              value={selectedServiceId}
              onChange={(e) => setSelectedServiceId(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl px-5 py-4 text-white focus:ring-2 focus:ring-emerald-500 outline-none transition-all disabled:opacity-50 appearance-none cursor-pointer"
              required
              disabled={!selectedCategory}
            >
              <option value="">Select Service</option>
              {filteredServices.map(s => (
                <option key={s.id} value={s.id}>{s.name} - ${s.rate}/1k</option>
              ))}
            </select>
          </div>

          {selectedService && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="bg-zinc-950 border border-zinc-800 rounded-2xl p-5 text-sm text-zinc-400"
            >
              <p className="font-black text-emerald-500 mb-2 uppercase text-[10px] tracking-widest">Service Description</p>
              <p className="leading-relaxed text-zinc-300">{selectedService.description}</p>
              <div className="mt-4 flex gap-4 text-[10px] font-black uppercase tracking-widest">
                <span className="bg-zinc-900 px-3 py-1 rounded-lg border border-zinc-800">Min: {selectedService.min}</span>
                <span className="bg-zinc-900 px-3 py-1 rounded-lg border border-zinc-800">Max: {selectedService.max}</span>
              </div>
            </motion.div>
          )}

          <div className="space-y-2">
            <label className="block text-xs font-black text-zinc-500 uppercase tracking-widest ml-1">Link</label>
            <input
              type="url"
              value={link}
              onChange={(e) => setLink(e.target.value)}
              placeholder="https://instagram.com/p/..."
              className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl px-5 py-4 text-white focus:ring-2 focus:ring-emerald-500 outline-none transition-all placeholder:text-zinc-800"
              required
            />
          </div>

          <div className="space-y-2">
            <label className="block text-xs font-black text-zinc-500 uppercase tracking-widest ml-1">Quantity</label>
            <input
              type="number"
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
              placeholder={`Min: ${selectedService?.min || 100}`}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl px-5 py-4 text-white focus:ring-2 focus:ring-emerald-500 outline-none transition-all placeholder:text-zinc-800"
              required
            />
          </div>

          <div className="bg-zinc-950 border border-zinc-800 rounded-[2rem] p-6 lg:p-8 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-inner">
            <div className="text-center sm:text-left">
              <p className="text-[10px] text-zinc-500 uppercase tracking-widest font-black mb-1">Total Charge</p>
              <p className="text-4xl font-black text-white tracking-tight">${totalCharge.toFixed(2)}</p>
            </div>
            <button
              type="submit"
              disabled={loading || !selectedServiceId || user.balance < totalCharge}
              className="w-full sm:w-auto bg-emerald-500 hover:bg-emerald-600 disabled:bg-zinc-800 disabled:text-zinc-600 text-black font-black px-10 py-5 rounded-2xl transition-all shadow-xl shadow-emerald-500/20 active:scale-95 uppercase tracking-widest text-sm"
            >
              {loading ? 'Processing...' : 'Place Order'}
            </button>
          </div>
          
          {error && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-2 text-red-500 text-xs font-bold bg-red-500/10 p-4 rounded-2xl border border-red-500/20">
              <AlertCircle size={14} />
              {error}
            </motion.div>
          )}
        </form>
      </motion.div>
    </div>
  );
};

const Services = ({ services }: { services: Service[] }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const categories = ['All', ...Array.from(new Set(services.map(s => s.category)))];

  const filteredServices = services.filter(service => {
    const matchesSearch = service.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         service.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         service.id.toString().includes(searchTerm);
    const matchesCategory = selectedCategory === 'All' || service.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-8">
      <div className="flex flex-col space-y-6">
        {/* Search Bar */}
        <div className="relative group">
          <div className="absolute inset-y-0 left-0 pl-6 flex items-center pointer-events-none">
            <Search className="text-zinc-500 group-focus-within:text-emerald-500 transition-colors" size={20} />
          </div>
          <input
            type="text"
            placeholder="Search for services (e.g. Instagram, Followers, ID...)"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-zinc-900/50 backdrop-blur-md border border-zinc-800 rounded-[2rem] pl-14 pr-6 py-5 text-white focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 outline-none transition-all placeholder:text-zinc-600 shadow-2xl"
          />
          {searchTerm && (
            <button 
              onClick={() => setSearchTerm('')}
              className="absolute inset-y-0 right-0 pr-6 flex items-center text-zinc-500 hover:text-white transition-colors"
            >
              <X size={18} />
            </button>
          )}
        </div>

        {/* Category Pills */}
        <div className="flex flex-col space-y-3">
          <div className="flex items-center gap-2 px-1">
            <Filter size={14} className="text-emerald-500" />
            <span className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em]">Filter by Category</span>
          </div>
          <div className="flex flex-wrap gap-2 pb-2">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-6 py-2.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all border ${
                  selectedCategory === cat 
                    ? 'bg-emerald-500 text-black border-emerald-500 shadow-lg shadow-emerald-500/20' 
                    : 'bg-zinc-900/50 text-zinc-500 border-zinc-800 hover:text-white hover:border-zinc-700'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Services Table */}
      <div className="bg-zinc-900/50 backdrop-blur-md border border-zinc-800 rounded-[2.5rem] overflow-hidden shadow-2xl">
        <div className="p-8 border-b border-zinc-800/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl font-black text-white uppercase tracking-tight">Available Services</h2>
            <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest mt-1">
              {filteredServices.length} {filteredServices.length === 1 ? 'service' : 'services'} available
            </p>
          </div>
          {selectedCategory !== 'All' && (
            <div className="bg-emerald-500/10 border border-emerald-500/20 px-4 py-2 rounded-xl flex items-center gap-2">
              <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">{selectedCategory}</span>
              <button onClick={() => setSelectedCategory('All')} className="text-emerald-500 hover:text-white transition-colors">
                <X size={14} />
              </button>
            </div>
          )}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-zinc-950/50 text-zinc-500 text-[10px] font-black uppercase tracking-widest">
              <tr>
                <th className="px-8 py-5">ID</th>
                <th className="px-8 py-5">Service Details</th>
                <th className="px-8 py-5">Rate (1k)</th>
                <th className="px-8 py-5">Min/Max</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/50">
              {filteredServices.map((service) => (
                <tr key={service.id} className="hover:bg-zinc-800/30 transition-colors group">
                  <td className="px-8 py-6 text-zinc-500 font-mono text-xs">#{service.id}</td>
                  <td className="px-8 py-6">
                    <p className="text-white font-bold text-sm group-hover:text-emerald-400 transition-colors">{service.name}</p>
                    <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest mt-1">{service.category}</p>
                  </td>
                  <td className="px-8 py-6">
                    <span className="text-emerald-500 font-black text-sm">${service.rate.toFixed(2)}</span>
                  </td>
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-2">
                      <span className="px-3 py-1.5 bg-zinc-950/50 border border-zinc-800 rounded-xl text-[10px] font-black text-zinc-400">{service.min}</span>
                      <span className="text-zinc-800 font-bold">/</span>
                      <span className="px-3 py-1.5 bg-zinc-950/50 border border-zinc-800 rounded-xl text-[10px] font-black text-zinc-400">{service.max}</span>
                    </div>
                  </td>
                </tr>
              ))}
              {filteredServices.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-8 py-24 text-center">
                    <div className="flex flex-col items-center justify-center space-y-4">
                      <div className="p-4 bg-zinc-900 rounded-full border border-zinc-800">
                        <Search size={32} className="text-zinc-700" />
                      </div>
                      <div>
                        <p className="text-white font-black uppercase tracking-widest text-sm">No services found</p>
                        <p className="text-zinc-500 text-xs mt-1">Try adjusting your search or filters</p>
                      </div>
                      <button 
                        onClick={() => { setSearchTerm(''); setSelectedCategory('All'); }}
                        className="text-emerald-500 text-[10px] font-black uppercase tracking-widest hover:underline mt-2"
                      >
                        Reset all filters
                      </button>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const OrderHistory = ({ orders }: { orders: Order[] }) => {
  return (
    <div className="bg-zinc-900/50 backdrop-blur-md border border-zinc-800 rounded-[2.5rem] overflow-hidden shadow-2xl">
      <div className="p-8 border-b border-zinc-800/50">
        <h2 className="text-2xl font-black text-white uppercase tracking-tight">Order History</h2>
        <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest mt-1">Track your panel activity</p>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead className="bg-zinc-950/50 text-zinc-500 text-[10px] font-black uppercase tracking-widest">
            <tr>
              <th className="px-8 py-5">ID</th>
              <th className="px-8 py-5">Date</th>
              <th className="px-8 py-5">Service</th>
              <th className="px-8 py-5">Link</th>
              <th className="px-8 py-5">Qty</th>
              <th className="px-8 py-5">Status</th>
              <th className="px-8 py-5">Charge</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-800/50">
            {orders.map((order) => (
              <tr key={order.id} className="hover:bg-zinc-800/30 transition-colors">
                <td className="px-8 py-6 text-zinc-500 font-mono text-xs">#{order.id}</td>
                <td className="px-8 py-6">
                  <p className="text-zinc-400 text-[10px] font-black uppercase tracking-widest">
                    {new Date(order.created_at).toLocaleDateString()}
                  </p>
                </td>
                <td className="px-8 py-6">
                  <p className="text-white font-bold text-sm truncate max-w-[200px]">{order.service_name}</p>
                </td>
                <td className="px-8 py-6">
                  <a href={order.link} target="_blank" rel="noreferrer" className="text-emerald-500 hover:text-emerald-400 transition-colors text-xs font-medium truncate max-w-[150px] block">
                    {order.link}
                  </a>
                </td>
                <td className="px-8 py-6 text-zinc-400 font-bold text-xs">{order.quantity}</td>
                <td className="px-8 py-6">
                  <span className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-tighter ${
                    order.status === 'completed' ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20' :
                    order.status === 'pending' ? 'bg-amber-500/10 text-amber-500 border border-amber-500/20' :
                    'bg-zinc-800/50 text-zinc-500 border border-zinc-700/50'
                  }`}>
                    {order.status}
                  </span>
                </td>
                <td className="px-8 py-6 text-white font-black text-sm">${order.charge.toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

const AddFunds = ({ user }: { user: User }) => {
  const [method, setMethod] = useState('bkash');
  const [amount, setAmount] = useState('');
  const [trxId, setTrxId] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage({ type: '', text: '' });

    try {
      const res = await fetch('/api/user/add-funds', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, method, amount: parseFloat(amount), trxId })
      });
      const data = await res.json();
      if (data.success) {
        setMessage({ type: 'success', text: 'Payment request submitted! Admin will verify soon.' });
        setAmount('');
        setTrxId('');
      } else {
        setMessage({ type: 'error', text: data.error });
      }
    } catch (err) {
      setMessage({ type: 'error', text: 'Failed to submit request' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid lg:grid-cols-2 gap-8">
      <motion.div 
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        className="bg-zinc-900/50 backdrop-blur-md border border-zinc-800 rounded-[2.5rem] p-8 lg:p-10 shadow-2xl"
      >
        <div className="flex items-center gap-4 mb-10">
          <div className="w-12 h-12 bg-emerald-500/10 rounded-2xl flex items-center justify-center text-emerald-500">
            <CreditCard size={24} />
          </div>
          <div>
            <h2 className="text-2xl font-black text-white uppercase tracking-tight">Add Funds</h2>
            <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest">Manual Payment Method</p>
          </div>
        </div>

        <div className="bg-zinc-950/50 border border-zinc-800 rounded-3xl p-6 mb-8 space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-pink-500/10 flex items-center justify-center text-pink-500 font-black text-xs uppercase tracking-tighter border border-pink-500/20">bKash</div>
            <div className="w-12 h-12 rounded-xl bg-orange-500/10 flex items-center justify-center text-orange-500 font-black text-xs uppercase tracking-tighter border border-orange-500/20">Nagad</div>
          </div>
          <div>
            <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest mb-2 ml-1">Personal Number (Send Money)</p>
            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl px-6 py-4 flex items-center justify-between group">
              <p className="text-2xl font-black text-white tracking-[0.2em]">01898694648</p>
              <button 
                onClick={() => {
                  navigator.clipboard.writeText('01898694648');
                  alert('Number copied!');
                }}
                className="text-[10px] font-black uppercase tracking-widest text-emerald-500 hover:text-emerald-400 transition-colors"
              >
                Copy
              </button>
            </div>
          </div>
          <div className="space-y-3">
            {[
              'Send money to the number above',
              'Copy the Transaction ID (TrxID)',
              'Fill the form with amount and TrxID',
              'Wait 5-30 minutes for verification'
            ].map((step, i) => (
              <div key={i} className="flex items-center gap-3 text-[10px] font-black uppercase tracking-widest text-zinc-500">
                <span className="w-5 h-5 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-emerald-500">{i + 1}</span>
                {step}
              </div>
            ))}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="grid grid-cols-2 gap-4">
            <button 
              type="button"
              onClick={() => setMethod('bkash')}
              className={`py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] border transition-all ${method === 'bkash' ? 'bg-pink-500 border-pink-500 text-white shadow-lg shadow-pink-500/20' : 'bg-zinc-950/50 border-zinc-800 text-zinc-500 hover:border-zinc-700'}`}
            >bKash</button>
            <button 
              type="button"
              onClick={() => setMethod('nagad')}
              className={`py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] border transition-all ${method === 'nagad' ? 'bg-orange-500 border-orange-500 text-white shadow-lg shadow-orange-500/20' : 'bg-zinc-950/50 border-zinc-800 text-zinc-500 hover:border-zinc-700'}`}
            >Nagad</button>
          </div>
          <div className="space-y-2">
            <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Amount (BDT)</label>
            <input
              type="number"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full bg-zinc-950/50 border border-zinc-800 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-emerald-500 transition-all placeholder:text-zinc-800"
              required
            />
          </div>
          <div className="space-y-2">
            <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Transaction ID (TrxID)</label>
            <input
              type="text"
              placeholder="Enter TrxID"
              value={trxId}
              onChange={(e) => setTrxId(e.target.value)}
              className="w-full bg-zinc-950/50 border border-zinc-800 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-emerald-500 transition-all placeholder:text-zinc-800"
              required
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-emerald-500 hover:bg-emerald-600 disabled:bg-zinc-800 disabled:text-zinc-600 text-black font-black py-5 rounded-2xl transition-all shadow-xl shadow-emerald-500/20 active:scale-95 uppercase tracking-widest text-sm mt-4"
          >
            {loading ? 'Processing...' : 'Submit Request'}
          </button>
          {message.text && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`p-4 rounded-2xl border text-[10px] font-black uppercase tracking-widest text-center ${
                message.type === 'success' ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' : 'bg-red-500/10 text-red-500 border-red-500/20'
              }`}
            >
              {message.text}
            </motion.div>
          )}
        </form>
      </motion.div>

      <div className="space-y-6">
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-zinc-900/50 backdrop-blur-md border border-zinc-800 rounded-[2.5rem] p-8 lg:p-10"
        >
          <h3 className="text-xl font-black text-white mb-6 uppercase tracking-tight">Payment Guide</h3>
          <p className="text-zinc-400 text-sm leading-relaxed font-medium">
            আমাদের পার্সোনাল নাম্বারে (01898694648) সেন্ড মানি করুন। সেন্ড মানি করার পর ট্রানজেকশন আইডি এবং কত টাকা পাঠিয়েছেন তা এখানে সাবমিট করুন। আমাদের অ্যাডমিন আপনার ট্রানজেকশন চেক করে ব্যালেন্স অ্যাড করে দিবে। সাধারণত ৫ থেকে ৩০ মিনিটের মধ্যে ব্যালেন্স অ্যাড হয়ে যায়।
          </p>
        </motion.div>
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-emerald-500/5 border border-emerald-500/10 rounded-[2.5rem] p-8 lg:p-10"
        >
          <div className="flex items-center gap-4 mb-4">
            <div className="w-10 h-10 bg-emerald-500/10 rounded-xl flex items-center justify-center text-emerald-500">
              <TrendingUp size={20} />
            </div>
            <h3 className="text-xl font-black text-emerald-500 uppercase tracking-tight">Support</h3>
          </div>
          <p className="text-zinc-500 text-sm font-medium">পেমেন্ট নিয়ে কোনো সমস্যা হলে আমাদের সাথে যোগাযোগ করুন। আমরা ২৪/৭ আপনার সেবায় নিয়োজিত।</p>
        </motion.div>
      </div>
    </div>
  );
};

const Profile = ({ user, onUpdate }: { user: User, onUpdate: () => void }) => {
  const [username, setUsername] = useState(user.username);
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage({ type: '', text: '' });

    try {
      const res = await fetch(`/api/user/${user.id}/profile`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password: password || undefined })
      });
      const data = await res.json();
      if (data.success) {
        setMessage({ type: 'success', text: 'Profile updated successfully!' });
        onUpdate();
        setPassword('');
      } else {
        setMessage({ type: 'error', text: data.error });
      }
    } catch (err) {
      setMessage({ type: 'error', text: 'Failed to update profile' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-zinc-900/50 backdrop-blur-md border border-zinc-800 rounded-[2.5rem] p-8 lg:p-10 shadow-2xl"
      >
        <div className="flex items-center gap-4 mb-10">
          <div className="w-12 h-12 bg-emerald-500/10 rounded-2xl flex items-center justify-center text-emerald-500">
            <User size={24} />
          </div>
          <div>
            <h2 className="text-2xl font-black text-white uppercase tracking-tight">Edit Profile</h2>
            <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest">Update your account information</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Email Address</label>
            <input
              type="email"
              value={user.email}
              disabled
              className="w-full bg-zinc-950/50 border border-zinc-800 rounded-2xl px-6 py-4 text-zinc-500 outline-none cursor-not-allowed"
            />
            <p className="text-[9px] text-zinc-600 ml-1 uppercase tracking-widest">Email cannot be changed</p>
          </div>

          <div className="space-y-2">
            <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Username</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-zinc-950/50 border border-zinc-800 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
              required
            />
          </div>

          <div className="space-y-2">
            <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">New Password</label>
            <input
              type="password"
              placeholder="Leave blank to keep current password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-zinc-950/50 border border-zinc-800 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-emerald-500 transition-all placeholder:text-zinc-800"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-emerald-500 hover:bg-emerald-600 disabled:bg-zinc-800 disabled:text-zinc-600 text-black font-black py-5 rounded-2xl transition-all shadow-xl shadow-emerald-500/20 active:scale-95 uppercase tracking-widest text-sm mt-4"
          >
            {loading ? 'Updating...' : 'Save Changes'}
          </button>

          {message.text && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`p-4 rounded-2xl border text-[10px] font-black uppercase tracking-widest text-center ${
                message.type === 'success' ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' : 'bg-red-500/10 text-red-500 border-red-500/20'
              }`}
            >
              {message.text}
            </motion.div>
          )}
        </form>
      </motion.div>
    </div>
  );
};

const ServiceModal = ({ service, onClose, onSave }: { service?: Service, onClose: () => void, onSave: (s: Partial<Service>) => void }) => {
  const [formData, setFormData] = useState<Partial<Service>>(service || {
    name: '',
    category: '',
    rate: 0,
    min: 10,
    max: 10000,
    description: ''
  });

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-xl z-[100] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-2xl bg-zinc-900 border border-zinc-800 rounded-[3rem] p-8 lg:p-12 shadow-2xl"
      >
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-2xl font-black text-white uppercase tracking-tight">{service ? 'Edit Service' : 'Add New Service'}</h2>
          <button onClick={onClose} className="p-2 text-zinc-500 hover:text-white transition-colors"><X size={24} /></button>
        </div>
        <div className="grid grid-cols-2 gap-6">
          <div className="space-y-2 col-span-2">
            <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Service Name</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full bg-zinc-950/50 border border-zinc-800 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
              placeholder="e.g. Instagram Followers [Real]"
            />
          </div>
          <div className="space-y-2">
            <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Category</label>
            <input
              type="text"
              value={formData.category}
              onChange={(e) => setFormData({ ...formData, category: e.target.value })}
              className="w-full bg-zinc-950/50 border border-zinc-800 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
              placeholder="e.g. Instagram"
            />
          </div>
          <div className="space-y-2">
            <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Rate (per 1k)</label>
            <input
              type="number"
              value={formData.rate}
              onChange={(e) => setFormData({ ...formData, rate: parseFloat(e.target.value) })}
              className="w-full bg-zinc-950/50 border border-zinc-800 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
            />
          </div>
          <div className="space-y-2">
            <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Min Quantity</label>
            <input
              type="number"
              value={formData.min}
              onChange={(e) => setFormData({ ...formData, min: parseInt(e.target.value) })}
              className="w-full bg-zinc-950/50 border border-zinc-800 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
            />
          </div>
          <div className="space-y-2">
            <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Max Quantity</label>
            <input
              type="number"
              value={formData.max}
              onChange={(e) => setFormData({ ...formData, max: parseInt(e.target.value) })}
              className="w-full bg-zinc-950/50 border border-zinc-800 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
            />
          </div>
          <div className="space-y-2 col-span-2">
            <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Description</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full bg-zinc-950/50 border border-zinc-800 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-emerald-500 transition-all h-24 resize-none"
              placeholder="Service details..."
            />
          </div>
        </div>
        <button
          onClick={() => onSave(formData)}
          className="w-full bg-emerald-500 hover:bg-emerald-600 text-black font-black py-5 rounded-2xl transition-all shadow-xl shadow-emerald-500/20 active:scale-95 uppercase tracking-widest text-sm mt-8"
        >
          {service ? 'Update Service' : 'Create Service'}
        </button>
      </motion.div>
    </div>
  );
};

const AdminPanel = ({ user }: { user: User }) => {
  const [adminTab, setAdminTab] = useState('users');
  const [users, setUsers] = useState<User[]>([]);
  const [orders, setOrders] = useState<(Order & { username: string })[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [payments, setPayments] = useState<any[]>([]);
  const [providerBalance, setProviderBalance] = useState<{ balance?: string, currency?: string }>({});
  const [loading, setLoading] = useState(true);
  const [newPassword, setNewPassword] = useState('');
  const [isServiceModalOpen, setIsServiceModalOpen] = useState(false);
  const [editingService, setEditingService] = useState<Service | undefined>();

  const fetchAdminData = async () => {
    setLoading(true);
    try {
      const [usersRes, ordersRes, servicesRes, balanceRes, paymentsRes] = await Promise.all([
        fetch('/api/admin/users'),
        fetch('/api/admin/orders'),
        fetch('/api/services'),
        fetch('/api/admin/provider-balance'),
        fetch('/api/admin/payments')
      ]);
      setUsers(await usersRes.json());
      setOrders(await ordersRes.json());
      setServices(await servicesRes.json());
      setProviderBalance(await balanceRes.json());
      setPayments(await paymentsRes.json());
    } catch (err) {
      console.error('Admin fetch error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, []);

  const handlePaymentAction = async (id: number, action: 'approve' | 'reject') => {
    await fetch(`/api/admin/payments/${id}/${action}`, { method: 'POST' });
    fetchAdminData();
  };

  const handleUpdateOrderStatus = async (orderId: number) => {
    const statuses = ['pending', 'processing', 'completed', 'cancelled'];
    const currentOrder = orders.find(o => o.id === orderId);
    const newStatus = prompt(`Current status: ${currentOrder?.status}\nEnter new status (${statuses.join(', ')}):`);
    
    if (!newStatus || !statuses.includes(newStatus.toLowerCase())) {
      if (newStatus) alert('Invalid status!');
      return;
    }

    await fetch(`/api/admin/orders/${orderId}/status`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: newStatus.toLowerCase() })
    });
    fetchAdminData();
  };

  const handleSaveService = async (serviceData: Partial<Service>) => {
    const method = editingService ? 'PUT' : 'POST';
    const url = editingService ? `/api/admin/services/${editingService.id}` : '/api/admin/services';
    
    await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(serviceData)
    });
    
    setIsServiceModalOpen(false);
    setEditingService(undefined);
    fetchAdminData();
  };

  const handleChangePassword = async () => {
    if (!newPassword) return;
    await fetch('/api/admin/change-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: user.id, newPassword })
    });
    alert('Password changed successfully!');
    setNewPassword('');
  };

  const handleAddBalance = async (userId: number) => {
    const amount = prompt('Enter amount to add:');
    if (!amount || isNaN(parseFloat(amount))) return;
    
    await fetch(`/api/admin/users/${userId}/balance`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ amount: parseFloat(amount) })
    });
    fetchAdminData();
  };

  const handleDeleteService = async (id: number) => {
    if (!confirm('Are you sure?')) return;
    await fetch(`/api/admin/services/${id}`, { method: 'DELETE' });
    fetchAdminData();
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 border-b border-zinc-800/50 pb-8">
        <div className="flex flex-wrap gap-3">
          {['users', 'services', 'all-orders', 'payments', 'settings'].map(tab => (
            <button
              key={tab}
              onClick={() => setAdminTab(tab)}
              className={`px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-[0.15em] transition-all border ${
                adminTab === tab 
                  ? 'bg-emerald-500 text-black border-emerald-500 shadow-xl shadow-emerald-500/20 active:scale-95' 
                  : 'text-zinc-500 border-zinc-800 hover:text-white hover:border-zinc-700 bg-zinc-900/30'
              }`}
            >
              {tab.replace('-', ' ')}
            </button>
          ))}
        </div>
        
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-zinc-900/50 backdrop-blur-md border border-zinc-800 px-6 py-4 rounded-[1.5rem] flex items-center gap-5 self-start lg:self-auto shadow-2xl"
        >
          <div className="relative">
            <div className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_15px_rgba(16,185,129,0.8)]"></div>
            <div className="absolute inset-0 w-3 h-3 rounded-full bg-emerald-500/50 animate-ping"></div>
          </div>
          <div className="flex flex-col">
            <span className="text-[9px] text-zinc-500 font-black uppercase tracking-[0.2em]">Provider Balance</span>
            <span className="text-lg font-black text-white tracking-tight">
              {providerBalance.balance ? `${providerBalance.balance} ${providerBalance.currency || ''}` : 'Syncing...'}
            </span>
          </div>
        </motion.div>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-32 space-y-6">
          <div className="relative">
            <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-emerald-500 border-r-2 border-emerald-500/20"></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
            </div>
          </div>
          <p className="text-zinc-500 font-black uppercase text-[10px] tracking-[0.3em] animate-pulse">Syncing Admin Data</p>
        </div>
      ) : (
        <motion.div 
          initial={{ opacity: 0, y: 20 }} 
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {adminTab === 'users' && (
            <div className="bg-zinc-900/50 backdrop-blur-md border border-zinc-800 rounded-[2.5rem] overflow-hidden shadow-2xl">
              <div className="p-8 border-b border-zinc-800/50">
                <h2 className="text-2xl font-black text-white uppercase tracking-tight">User Management</h2>
                <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest mt-1">Manage accounts and balances</p>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-zinc-950/50 text-zinc-500 text-[10px] font-black uppercase tracking-widest">
                    <tr>
                      <th className="px-8 py-5">ID</th>
                      <th className="px-8 py-5">User Profile</th>
                      <th className="px-8 py-5">Balance</th>
                      <th className="px-8 py-5">Role</th>
                      <th className="px-8 py-5">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800/50">
                    {users.map(u => (
                      <tr key={u.id} className="hover:bg-zinc-800/30 transition-colors group">
                        <td className="px-8 py-6 text-zinc-500 font-mono text-xs">#{u.id}</td>
                        <td className="px-8 py-6">
                          <p className="text-white font-bold text-sm group-hover:text-emerald-400 transition-colors">{u.username}</p>
                          <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest mt-1">Active Account</p>
                        </td>
                        <td className="px-8 py-6">
                          <span className="text-emerald-500 font-black text-sm">${u.balance.toFixed(2)}</span>
                        </td>
                        <td className="px-8 py-6">
                          <span className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-tighter ${u.is_admin ? 'bg-purple-500/10 text-purple-500 border border-purple-500/20' : 'bg-zinc-800/50 text-zinc-500 border border-zinc-700/50'}`}>
                            {u.is_admin ? 'Admin' : 'User'}
                          </span>
                        </td>
                        <td className="px-8 py-6">
                          <button 
                            onClick={() => handleAddBalance(u.id)}
                            className="text-[10px] font-black uppercase tracking-widest bg-emerald-500/10 text-emerald-500 px-5 py-2.5 rounded-xl border border-emerald-500/20 hover:bg-emerald-500 hover:text-black transition-all active:scale-95"
                          >
                            Add Funds
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {adminTab === 'services' && (
            <div className="bg-zinc-900/50 backdrop-blur-md border border-zinc-800 rounded-[2.5rem] overflow-hidden shadow-2xl">
              <div className="p-8 border-b border-zinc-800/50 flex justify-between items-center">
                <div>
                  <h2 className="text-2xl font-black text-white uppercase tracking-tight">Manage Services</h2>
                  <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest mt-1">Control panel service offerings</p>
                </div>
                <button 
                  onClick={() => { setEditingService(undefined); setIsServiceModalOpen(true); }}
                  className="bg-emerald-500 text-black px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl shadow-emerald-500/20 hover:bg-emerald-600 transition-all active:scale-95"
                >
                  + Add New
                </button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-zinc-950/50 text-zinc-500 text-[10px] font-black uppercase tracking-widest">
                    <tr>
                      <th className="px-8 py-5">ID</th>
                      <th className="px-8 py-5">Service Details</th>
                      <th className="px-8 py-5">Rate</th>
                      <th className="px-8 py-5">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800/50">
                    {services.map(s => (
                      <tr key={s.id} className="hover:bg-zinc-800/30 transition-colors group">
                        <td className="px-8 py-6 text-zinc-500 font-mono text-xs">#{s.id}</td>
                        <td className="px-8 py-6">
                          <p className="text-white font-bold text-sm group-hover:text-emerald-400 transition-colors">{s.name}</p>
                          <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest mt-1">Category: {s.category}</p>
                        </td>
                        <td className="px-8 py-6 text-emerald-500 font-black text-sm">${s.rate}</td>
                        <td className="px-8 py-6">
                          <div className="flex gap-2">
                            <button 
                              onClick={() => { setEditingService(s); setIsServiceModalOpen(true); }}
                              className="p-3 bg-zinc-950/50 border border-zinc-800 rounded-xl text-zinc-500 hover:text-white hover:border-zinc-700 transition-all active:scale-90"
                            >
                              <Edit size={16} />
                            </button>
                            <button onClick={() => handleDeleteService(s.id)} className="p-3 bg-zinc-950/50 border border-zinc-800 rounded-xl text-zinc-500 hover:text-red-500 hover:border-red-500/20 transition-all active:scale-90"><Trash2 size={16} /></button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {adminTab === 'all-orders' && (
            <div className="bg-zinc-900/50 backdrop-blur-md border border-zinc-800 rounded-[2.5rem] overflow-hidden shadow-2xl">
              <div className="p-8 border-b border-zinc-800/50">
                <h2 className="text-2xl font-black text-white uppercase tracking-tight">Global Orders</h2>
                <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest mt-1">Monitor all platform activity</p>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-zinc-950/50 text-zinc-500 text-[10px] font-black uppercase tracking-widest">
                    <tr>
                      <th className="px-8 py-5">ID</th>
                      <th className="px-8 py-5">User</th>
                      <th className="px-8 py-5">Service</th>
                      <th className="px-8 py-5">Qty</th>
                      <th className="px-8 py-5">Status</th>
                      <th className="px-8 py-5">Charge</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800/50">
                    {orders.map(o => (
                      <tr key={o.id} className="hover:bg-zinc-800/30 transition-colors">
                        <td className="px-8 py-6 text-zinc-500 font-mono text-xs">#{o.id}</td>
                        <td className="px-8 py-6 font-bold text-sm text-white">{o.username}</td>
                        <td className="px-8 py-6 text-zinc-400 text-xs max-w-[200px] truncate font-medium">{o.service_name}</td>
                        <td className="px-8 py-6 text-zinc-500 font-black text-xs">{o.quantity}</td>
                        <td className="px-8 py-6">
                          <div className="flex items-center gap-3">
                            <span className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-tighter ${o.status === 'completed' ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20' : 'bg-amber-500/10 text-amber-500 border border-amber-500/20'}`}>
                              {o.status}
                            </span>
                            <button 
                              onClick={() => handleUpdateOrderStatus(o.id)}
                              className="p-2 bg-zinc-950/50 border border-zinc-800 rounded-lg text-zinc-500 hover:text-white transition-all"
                            >
                              <Edit size={12} />
                            </button>
                          </div>
                        </td>
                        <td className="px-8 py-6 text-white font-black text-sm">${o.charge.toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {adminTab === 'payments' && (
            <div className="bg-zinc-900/50 backdrop-blur-md border border-zinc-800 rounded-[2.5rem] overflow-hidden shadow-2xl">
              <div className="p-8 border-b border-zinc-800/50">
                <h2 className="text-2xl font-black text-white uppercase tracking-tight">Payment Requests</h2>
                <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest mt-1">Verify manual transactions</p>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-zinc-950/50 text-zinc-500 text-[10px] font-black uppercase tracking-widest">
                    <tr>
                      <th className="px-8 py-5">User</th>
                      <th className="px-8 py-5">Method</th>
                      <th className="px-8 py-5">Amount</th>
                      <th className="px-8 py-5">TrxID</th>
                      <th className="px-8 py-5">Status</th>
                      <th className="px-8 py-5">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800/50">
                    {payments.map(p => (
                      <tr key={p.id} className="hover:bg-zinc-800/30 transition-colors">
                        <td className="px-8 py-6 font-bold text-sm text-white">{p.username}</td>
                        <td className="px-8 py-6">
                          <span className={`px-2 py-1 rounded-lg text-[10px] font-black uppercase tracking-tighter ${p.method === 'bkash' ? 'bg-pink-500/10 text-pink-500' : 'bg-orange-500/10 text-orange-500'}`}>
                            {p.method}
                          </span>
                        </td>
                        <td className="px-8 py-6 text-emerald-500 font-black text-sm">${p.amount}</td>
                        <td className="px-8 py-6 text-zinc-500 font-mono text-xs tracking-widest">{p.trx_id}</td>
                        <td className="px-8 py-6">
                          <span className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-tighter ${
                            p.status === 'approved' ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20' : 
                            p.status === 'rejected' ? 'bg-red-500/10 text-red-500 border border-red-500/20' : 
                            'bg-amber-500/10 text-amber-500 border border-amber-500/20'
                          }`}>
                            {p.status}
                          </span>
                        </td>
                        <td className="px-8 py-6">
                          {p.status === 'pending' && (
                            <div className="flex gap-2">
                              <button 
                                onClick={() => handlePaymentAction(p.id, 'approve')}
                                className="bg-emerald-500 text-black px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-emerald-600 transition-all active:scale-95 shadow-lg shadow-emerald-500/20"
                              >Approve</button>
                              <button 
                                onClick={() => handlePaymentAction(p.id, 'reject')}
                                className="bg-red-500/10 text-red-500 border border-red-500/20 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-red-500 hover:text-white transition-all active:scale-95"
                              >Reject</button>
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {adminTab === 'settings' && (
            <div className="max-w-xl">
              <div className="bg-zinc-900/50 backdrop-blur-md border border-zinc-800 rounded-[2.5rem] p-8 lg:p-10 shadow-2xl">
                <h3 className="text-2xl font-black text-white mb-8 uppercase tracking-tight">Admin Settings</h3>
                <div className="space-y-6">
                  <div className="space-y-2">
                    <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Change Admin Password</label>
                    <input
                      type="password"
                      placeholder="Enter new password"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="w-full bg-zinc-950/50 border border-zinc-800 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-emerald-500 transition-all placeholder:text-zinc-800"
                    />
                  </div>
                  <button
                    onClick={handleChangePassword}
                    className="w-full bg-emerald-500 hover:bg-emerald-600 text-black font-black py-5 rounded-2xl transition-all shadow-xl shadow-emerald-500/20 active:scale-95 uppercase tracking-widest text-sm"
                  >
                    Update Password
                  </button>
                </div>
              </div>
            </div>
          )}
        </motion.div>
      )}
      {isServiceModalOpen && (
        <ServiceModal 
          service={editingService} 
          onClose={() => { setIsServiceModalOpen(false); setEditingService(undefined); }} 
          onSave={handleSaveService} 
        />
      )}
    </div>
  );
};

const ResetPassword = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const token = searchParams.get('token');
  const [newPassword, setNewPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setLoading(true);
    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token, newPassword })
      });
      const data = await res.json();
      if (data.success) {
        setMessage({ type: 'success', text: 'Password reset successful! Redirecting to login...' });
        setTimeout(() => navigate('/login'), 3000);
      } else {
        setMessage({ type: 'error', text: data.error });
      }
    } catch (err) {
      setMessage({ type: 'error', text: 'Failed to reset password' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md bg-zinc-900/40 backdrop-blur-2xl border border-white/5 rounded-[3rem] p-8 lg:p-12 shadow-2xl"
      >
        <h2 className="text-2xl font-black text-white uppercase tracking-tight mb-6 text-center">Reset Password</h2>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">New Password</label>
            <input
              type="password"
              placeholder="Enter your new password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="w-full bg-zinc-950/50 border border-zinc-800 rounded-2xl px-6 py-4 text-white outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
              required
            />
          </div>
          <button
            type="submit"
            disabled={loading || !token}
            className="w-full bg-emerald-500 hover:bg-emerald-600 text-black font-black py-5 rounded-2xl transition-all shadow-xl shadow-emerald-500/20 active:scale-95 uppercase tracking-widest text-sm"
          >
            {loading ? 'Resetting...' : 'Reset Password'}
          </button>
          {message.text && (
            <p className={`text-center text-[10px] font-black uppercase tracking-widest mt-4 ${message.type === 'success' ? 'text-emerald-500' : 'text-red-500'}`}>
              {message.text}
            </p>
          )}
        </form>
      </motion.div>
    </div>
  );
};

const Auth = ({ onLogin, type }: { onLogin: (user: User) => void, type: 'login' | 'register' | 'forgot-password' }) => {
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginInput, setLoginInput] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  const isLogin = type === 'login';
  const isRegister = type === 'register';
  const isForgot = type === 'forgot-password';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccessMessage('');
    
    let endpoint = '';
    let body = {};

    if (isLogin) {
      endpoint = '/api/auth/login';
      body = { login: loginInput, password };
    } else if (isRegister) {
      endpoint = '/api/auth/register';
      body = { username, email, password };
    } else if (isForgot) {
      endpoint = '/api/auth/forgot-password';
      body = { email };
    }
    
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      
      const data = await res.json();
      if (data.success) {
        if (isLogin) {
          onLogin(data.user);
          navigate('/');
        } else if (isRegister) {
          setSuccessMessage('Registration successful! Redirecting to login...');
          setTimeout(() => navigate('/login'), 2000);
          setUsername(''); setEmail(''); setPassword('');
        } else if (isForgot) {
          setSuccessMessage('Password reset link sent to your email!');
          setEmail('');
        }
      } else {
        setError(data.error);
      }
    } catch (err) {
      setError('Connection error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-emerald-500/10 rounded-full blur-[120px] animate-pulse"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-500/10 rounded-full blur-[120px] animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="w-full max-w-md bg-zinc-900/40 backdrop-blur-2xl border border-white/5 rounded-[3rem] p-8 lg:p-12 shadow-2xl relative z-10"
      >
        <div className="text-center mb-10">
          <motion.div 
            initial={{ rotate: -10 }}
            animate={{ rotate: 0 }}
            className="w-24 h-24 bg-gradient-to-br from-emerald-400 to-emerald-600 rounded-[2rem] flex items-center justify-center mx-auto mb-6 shadow-xl shadow-emerald-500/20"
          >
            <TrendingUp className="text-black" size={48} />
          </motion.div>
          <h1 className="text-4xl font-black text-white tracking-tighter uppercase">badhon smm</h1>
          <p className="text-zinc-500 mt-3 font-bold uppercase text-[10px] tracking-[0.2em]">
            {isLogin ? 'Welcome Back' : isRegister ? 'Create Account' : 'Reset Password'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {isLogin && (
            <>
              <div className="space-y-2">
                <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Username or Email</label>
                <input
                  type="text"
                  value={loginInput}
                  onChange={(e) => setLoginInput(e.target.value)}
                  className="w-full bg-zinc-950/50 border border-zinc-800 rounded-2xl px-6 py-4 text-white focus:ring-2 focus:ring-emerald-500 outline-none transition-all placeholder:text-zinc-800"
                  placeholder="Enter credentials"
                  required
                />
              </div>
              <div className="space-y-2">
                <div className="flex justify-between items-center px-1">
                  <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest">Password</label>
                  <Link to="/forgot-password" size={10} className="text-[10px] font-black text-emerald-500 uppercase tracking-widest hover:underline">Forgot?</Link>
                </div>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-zinc-950/50 border border-zinc-800 rounded-2xl px-6 py-4 text-white focus:ring-2 focus:ring-emerald-500 outline-none transition-all placeholder:text-zinc-800"
                  placeholder="••••••••"
                  required
                />
              </div>
            </>
          )}

          {isRegister && (
            <>
              <div className="space-y-2">
                <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Username</label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full bg-zinc-950/50 border border-zinc-800 rounded-2xl px-6 py-4 text-white focus:ring-2 focus:ring-emerald-500 outline-none transition-all placeholder:text-zinc-800"
                  placeholder="Choose username"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Email Address</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-zinc-950/50 border border-zinc-800 rounded-2xl px-6 py-4 text-white focus:ring-2 focus:ring-emerald-500 outline-none transition-all placeholder:text-zinc-800"
                  placeholder="your@email.com"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Password</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-zinc-950/50 border border-zinc-800 rounded-2xl px-6 py-4 text-white focus:ring-2 focus:ring-emerald-500 outline-none transition-all placeholder:text-zinc-800"
                  placeholder="••••••••"
                  required
                />
              </div>
            </>
          )}

          {isForgot && (
            <div className="space-y-2">
              <label className="block text-[10px] font-black text-zinc-500 uppercase tracking-widest ml-1">Email Address</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-zinc-950/50 border border-zinc-800 rounded-2xl px-6 py-4 text-white focus:ring-2 focus:ring-emerald-500 outline-none transition-all placeholder:text-zinc-800"
                placeholder="your@email.com"
                required
              />
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-emerald-500 hover:bg-emerald-600 disabled:bg-zinc-800 disabled:text-zinc-600 text-black font-black py-5 rounded-2xl transition-all shadow-xl shadow-emerald-500/20 active:scale-95 uppercase tracking-widest text-sm mt-4"
          >
            {loading ? 'Processing...' : isLogin ? 'Sign In' : isRegister ? 'Create Account' : 'Send Reset Link'}
          </button>

          <div className="text-center mt-6">
            {isLogin ? (
              <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest">
                Don't have an account? <Link to="/register" className="text-emerald-500 hover:underline">Sign Up</Link>
              </p>
            ) : (
              <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest">
                Already have an account? <Link to="/login" className="text-emerald-500 hover:underline">Sign In</Link>
              </p>
            )}
          </div>

          {error && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-2 text-red-500 text-[10px] font-black uppercase tracking-widest bg-red-500/10 p-4 rounded-2xl border border-red-500/20">
              <AlertCircle size={14} />
              {error}
            </motion.div>
          )}

          {successMessage && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-2 text-emerald-500 text-[10px] font-black uppercase tracking-widest bg-emerald-500/10 p-4 rounded-2xl border border-emerald-500/20">
              <CheckCircle2 size={14} />
              {successMessage}
            </motion.div>
          )}
        </form>
      </motion.div>
    </div>
  );
};

export default function App() {
  const navigate = useNavigate();
  const location = useLocation();
  const [user, setUser] = useState<User | null>(null);
  const [services, setServices] = useState<Service[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const fetchData = async () => {
    if (!user) return;
    try {
      const [servicesRes, ordersRes, userRes] = await Promise.all([
        fetch('/api/services'),
        fetch(`/api/orders/${user.id}`),
        fetch(`/api/user/${user.id}`)
      ]);
      
      const [servicesData, ordersData, userData] = await Promise.all([
        servicesRes.json(),
        ordersRes.json(),
        userRes.json()
      ]);
      
      setServices(servicesData);
      setOrders(ordersData);
      setUser(userData);
    } catch (err) {
      console.error('Failed to fetch data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const savedUser = localStorage.getItem('smm_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    } else {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (user) {
      fetchData();
      localStorage.setItem('smm_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('smm_user');
    }
  }, [user?.id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-emerald-500"></div>
      </div>
    );
  }

  const handleLogout = () => {
    setUser(null);
    navigate('/login');
  };

  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/" /> : <Auth onLogin={setUser} type="login" />} />
      <Route path="/register" element={user ? <Navigate to="/" /> : <Auth onLogin={setUser} type="register" />} />
      <Route path="/forgot-password" element={user ? <Navigate to="/" /> : <Auth onLogin={setUser} type="forgot-password" />} />
      <Route path="/reset-password" element={user ? <Navigate to="/" /> : <ResetPassword />} />
      
      {/* Dedicated Admin Route - Separate from User Dashboard */}
      <Route path="/admin/*" element={
        user?.is_admin ? (
          <div className="min-h-screen bg-zinc-950 text-white flex flex-col">
            <nav className="bg-zinc-900 border-b border-zinc-800 px-8 py-4 flex items-center justify-between sticky top-0 z-50">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-emerald-500 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/20">
                  <ShieldCheck className="text-black" size={24} />
                </div>
                <div>
                  <h1 className="text-lg font-black uppercase tracking-tighter">Admin Control</h1>
                  <p className="text-[9px] text-zinc-500 font-black uppercase tracking-widest">badhon smm panel</p>
                </div>
              </div>
              <div className="flex items-center gap-6">
                <div className="hidden md:flex flex-col items-end">
                  <span className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Logged in as</span>
                  <span className="text-sm font-bold">{user.username}</span>
                </div>
                <button 
                  onClick={handleLogout}
                  className="flex items-center gap-2 bg-zinc-800 hover:bg-red-500/10 hover:text-red-500 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all border border-zinc-700 hover:border-red-500/20"
                >
                  <LogOut size={14} />
                  Exit
                </button>
              </div>
            </nav>
            <div className="flex-1 p-4 lg:p-12 max-w-7xl mx-auto w-full">
              <AdminPanel user={user} />
            </div>
          </div>
        ) : (
          <Navigate to="/login" />
        )
      } />
      
      <Route path="/*" element={
        user ? (
          <div className="min-h-screen bg-black text-white">
            <Sidebar 
              user={user} 
              onLogout={handleLogout}
              isOpen={isMobileMenuOpen}
              onClose={() => setIsMobileMenuOpen(false)}
            />
            
            <main className="lg:ml-64 p-4 lg:p-8 min-h-screen">
              {/* Mobile Header */}
              <header className="lg:hidden flex items-center justify-between mb-8 bg-zinc-900/50 backdrop-blur-md border border-zinc-800 p-4 rounded-2xl">
                <button onClick={() => setIsMobileMenuOpen(true)} className="p-2 text-zinc-400 hover:text-white">
                  <Menu size={24} />
                </button>
                <Link to="/" className="text-xl font-bold text-white flex items-center gap-2">
                  <TrendingUp className="text-emerald-500" size={20} />
                  badhon smm
                </Link>
                <div className="w-10 h-10 rounded-full bg-emerald-500/10 flex items-center justify-center">
                  <User className="text-emerald-500" size={20} />
                </div>
              </header>

              <header className="hidden lg:flex items-center justify-between mb-12">
                <div>
                  <h1 className="text-3xl font-bold text-white capitalize">
                    {location.pathname === '/' ? 'Dashboard' : location.pathname.substring(1).replace('-', ' ')}
                  </h1>
                  <p className="text-zinc-500 mt-1">Manage your social media presence with ease.</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="bg-zinc-900 border border-zinc-800 rounded-2xl px-6 py-3 flex items-center gap-3">
                    <User className="text-emerald-500" size={20} />
                    <div className="flex flex-col">
                      <span className="text-xs text-zinc-500 font-black uppercase tracking-tighter">User ID: #{user.id}</span>
                      <span className="font-bold text-sm">{user.username}</span>
                    </div>
                  </div>
                </div>
              </header>

              <AnimatePresence mode="wait">
                <motion.div
                  key={location.pathname}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                >
                  <Routes>
                    <Route path="/" element={<Dashboard user={user} orders={orders} />} />
                    <Route path="/new-order" element={<NewOrder services={services} user={user} onOrderPlaced={fetchData} />} />
                    <Route path="/add-funds" element={<AddFunds user={user} />} />
                    <Route path="/services" element={<Services services={services} />} />
                    <Route path="/orders" element={<OrderHistory orders={orders} />} />
                    <Route path="/profile" element={<Profile user={user} onUpdate={fetchData} />} />
                    <Route path="*" element={<Navigate to="/" />} />
                  </Routes>
                </motion.div>
              </AnimatePresence>
            </main>
          </div>
        ) : (
          <Navigate to="/login" />
        )
      } />
    </Routes>
  );
}
